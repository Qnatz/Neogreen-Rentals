package com.example.myapplicationx.database.model // Adjust package name as needed

data class OccupancyStatus(
    val vacantUnits: Int,
    val occupiedUnits: Int
)