package com.example.myapplicationx.ui.settings.companySignature

data class CompanySignature(
    val signatureUrl: String = ""
)